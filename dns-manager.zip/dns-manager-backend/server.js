// server.js

const express = require('express');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const { JWT_SECRET } = require('./config'); // Import your JWT secret from config file
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// Sample users data (for demonstration purposes)
const users = [
  { id: 1, username: 'admin', password: '$2a$10$WuSgCGTcNkiL76Ujgg8lLeWkfI1SJo1wQiCafFAOk3vQvP/l6EoPm' } // hashed password: "password"
];

// Sample DNS records data (for demonstration purposes)
const dnsRecords = [
  { id: uuidv4(), domain: 'example.com', recordType: 'A', value: '192.0.2.1' },
  { id: uuidv4(), domain: 'example.com', recordType: 'MX', value: 'mail.example.com' }
];

// Dummy authentication middleware
function authenticateUser(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Forbidden' });
    req.user = user;
    next();
  });
}

// Dummy authentication endpoint
app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(user => user.username === username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET);
  res.json({ token });
});

// CRUD endpoints for DNS records
app.get('/dns/records', authenticateUser, (req, res) => {
  res.json(dnsRecords);
});

app.post('/dns/records', authenticateUser, (req, res) => {
  const { domain, recordType, value } = req.body;
  const newRecord = { id: uuidv4(), domain, recordType, value };
  dnsRecords.push(newRecord);
  res.status(201).json(newRecord);
});

app.put('/dns/records/:id', authenticateUser, (req, res) => {
  const { id } = req.params;
  const { domain, recordType, value } = req.body;
  const index = dnsRecords.findIndex(record => record.id === id);
  if (index === -1) return res.status(404).json({ error: 'Record not found' });
  dnsRecords[index] = { id, domain, recordType, value };
  res.json(dnsRecords[index]);
});

app.delete('/dns/records/:id', authenticateUser, (req, res) => {
  const { id } = req.params;
  const index = dnsRecords.findIndex(record => record.id === id);
  if (index === -1) return res.status(404).json({ error: 'Record not found' });
  dnsRecords.splice(index, 1);
  res.status(204).send();
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
