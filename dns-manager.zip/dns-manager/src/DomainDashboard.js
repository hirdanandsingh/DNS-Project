import React from 'react';
import DomainTable from './DomainTable';
import DomainForm from './DomainForm';
import DomainCharts from './DomainCharts';

function DomainDashboard() {
  return (
    <div>
      <DomainForm />
      <DomainCharts />
      <DomainTable />
    </div>
  );
}

export default DomainDashboard;
