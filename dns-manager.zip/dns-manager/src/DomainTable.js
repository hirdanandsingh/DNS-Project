import React from 'react';

function DomainTable({ domains }) {
  return (
    <div className="domain-table">
      <h2>Domains</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Domain Name</th>
            <th>DNS Records</th>
          </tr>
        </thead>
        <tbody>
          {domains.map(domain => (
            <tr key={domain.id}>
              <td>{domain.id}</td>
              <td>{domain.domainName}</td>
              <td>{domain.dnsRecords.join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DomainTable;
