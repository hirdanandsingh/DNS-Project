import React from 'react';
import DomainDashboard from './DomainDashboard';

function Dashboard() {
  return (
    <div className="dashboard">
      <h1>Domain Dashboard</h1>
      <DomainDashboard />
    </div>
  );
}

export default Dashboard;
